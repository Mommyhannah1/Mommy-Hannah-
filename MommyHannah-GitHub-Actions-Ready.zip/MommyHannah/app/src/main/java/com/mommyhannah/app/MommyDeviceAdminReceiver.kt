package com.mommyhannah.app

import android.app.admin.DeviceAdminReceiver

class MommyDeviceAdminReceiver : DeviceAdminReceiver()
