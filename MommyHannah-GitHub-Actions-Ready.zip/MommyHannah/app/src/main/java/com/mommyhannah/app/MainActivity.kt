package com.mommyhannah.app

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val adminComponent by lazy { ComponentName(this, MommyDeviceAdminReceiver::class.java) }
    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    private val purple = Color.rgb(124, 92, 252)
    private val dark = Color.rgb(24, 21, 31)
    private val muted = Color.rgb(111, 104, 122)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 247, 252)
        window.navigationBarColor = Color.rgb(248, 247, 252)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(248,247,252)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "♥"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded(purple, 18f)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14),0,0,0) }
        titles.addView(TextView(this).apply { text = "Mommy Hannah"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(dark) })
        titles.addView(TextView(this).apply { text = "Family device management"; textSize = 14f; setTextColor(muted) })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)

        status = TextView(this).apply { textSize = 14f; setTextColor(dark); setPadding(dp(16),dp(14),dp(16),dp(14)) }
        root.addView(status, margin(0,20,0,0))

        section(root, "PARENT CONTROLS")
        actionCard(root, "Device management", "Authorize this device for parent-managed locking", "Enable", ::enableAdmin)
        actionCard(root, "Lock managed device", "Lock the screen immediately when management is enabled", "Lock", ::lockDevice)

        section(root, "TIME & APPS")
        actionCard(root, "Screen time & usage", "Review Android usage-access settings and usage controls", "Open", ::openUsageAccess)
        actionCard(root, "App management", "Open Android app settings to manage installed apps", "Open", ::openAppSettings)

        section(root, "SAFETY")
        actionCard(root, "Web & device settings", "Configure network, browser and device safety settings", "Open", ::openSettings)
        actionCard(root, "Emergency / SOS", "Review emergency contacts and Android safety features", "View", ::showSosInfo)

        val footer = TextView(this).apply {
            text = "Mommy Hannah only uses visible Android permissions and controls. The managed device user can see and revoke device administration."
            textSize = 12f; setTextColor(muted); setPadding(dp(4),dp(20),dp(4),0)
        }
        root.addView(footer)
        setContentView(scroll)
        refreshStatus()
    }

    private fun section(root: LinearLayout, label: String) {
        root.addView(TextView(this).apply {
            text = label; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(purple); letterSpacing = .08f
            setPadding(dp(4),dp(22),dp(4),dp(8))
        })
    }

    private fun actionCard(root: LinearLayout, title: String, subtitle: String, button: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16),dp(14),dp(10),dp(14))
            background = rounded(Color.WHITE, 18f)
            elevation = dp(2).toFloat()
        }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        text.addView(TextView(this).apply { this.text=title; textSize=16f; typeface=Typeface.DEFAULT_BOLD; setTextColor(dark) })
        text.addView(TextView(this).apply { this.text=subtitle; textSize=12f; setTextColor(muted); setPadding(0,dp(3),0,0) })
        card.addView(text, LinearLayout.LayoutParams(0,-2,1f))
        card.addView(Button(this).apply { this.text=button; setTextColor(purple); isAllCaps=false; setOnClickListener{action()} }, LinearLayout.LayoutParams(dp(78),dp(48)))
        root.addView(card, margin(0,6,0,0))
    }

    private fun refreshStatus() {
        if (dpm.isAdminActive(adminComponent)) {
            status.text = "✓  Device management is enabled\nThis device is authorized for parent-managed locking."
            status.setTextColor(Color.rgb(39,120,79)); status.background = rounded(Color.rgb(231,248,239), 16f)
        } else {
            status.text = "○  Device management is not enabled\nEnable it on a device you own or are authorized to manage."
            status.setTextColor(Color.rgb(100,80,20)); status.background = rounded(Color.rgb(255,247,220), 16f)
        }
    }

    private fun enableAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Mommy Hannah uses device administration only for parent-authorized device locking. The user will see this Android authorization screen.")
        })
    }
    private fun lockDevice() {
        if (dpm.isAdminActive(adminComponent)) dpm.lockNow()
        else Toast.makeText(this, "Enable device management first.", Toast.LENGTH_SHORT).show()
    }
    private fun openUsageAccess() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    private fun openAppSettings() { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }
    private fun openSettings() { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    private fun showSosInfo() {
        AlertDialog.Builder(this).setTitle("Emergency / SOS")
            .setMessage("Use Android Emergency SOS and trusted contacts for emergency actions. Mommy Hannah does not secretly access messages, microphones, cameras, or contacts.")
            .setPositiveButton("OK", null).show()
    }
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }
    private fun margin(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
