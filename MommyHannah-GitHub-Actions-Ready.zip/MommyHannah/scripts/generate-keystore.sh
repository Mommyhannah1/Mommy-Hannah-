#!/usr/bin/env bash
set -euo pipefail
KEYSTORE="${1:-mommy-hannah-release.jks}"
keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -alias mommy-hannah \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -dname "CN=Mommy Hannah, OU=Mobile, O=Mommy Hannah, L=Faisalabad, ST=Punjab, C=PK"
echo "Created $KEYSTORE. Store it securely and never commit it to source control."
