# Mommy Hannah — Android Release Project

A polished, visible family-device-management app for devices you own or are authorized to manage.

## Included
- Branded launcher icon
- Android 12+ splash screen
- Polished parent dashboard
- Visible Device Administrator enrollment
- Authorized device locking
- Android usage-access and app-management shortcuts
- Safety/SOS guidance
- Release build configuration
- Environment-variable based release signing

## Build debug APK
Open the project in Android Studio and choose **Build > Build APK(s)**.

## Configure release signing
Do not commit a private keystore or passwords. Set these environment variables before building:

```text
MOMMY_HANNAH_KEYSTORE=/absolute/path/to/mommy-hannah-release.jks
MOMMY_HANNAH_STORE_PASSWORD=your-store-password
MOMMY_HANNAH_KEY_ALIAS=mommy-hannah
MOMMY_HANNAH_KEY_PASSWORD=your-key-password
```

Then run:

```bash
./gradlew assembleRelease
```

The release APK will be at:

`app/build/outputs/apk/release/app-release.apk`

## Generate a new release keystore
Use the included `scripts/generate-keystore.sh` on macOS/Linux, or the equivalent `keytool` command on Windows.

Keep the `.jks` file and passwords private. If you lose the signing key, future updates cannot be signed with the same identity.

## Important
The app intentionally uses visible Android authorization flows. It does not implement hidden surveillance, credential theft, or covert remote control.
